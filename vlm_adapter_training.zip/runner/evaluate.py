from torch.utils.data import DataLoader
from tqdm import tqdm
import torch

def evaluate_model(model, dataset, preprocess_fn=None, batch_size=8, device="cuda"):
    loader = DataLoader(dataset, batch_size=batch_size)
    model.eval()
    model.to(device)

    total_correct = 0
    total_samples = 0

    for batch in tqdm(loader, desc="Evaluating"):
        inputs = preprocess_fn(batch) if preprocess_fn else batch
        labels = batch["labels"].to(device)

        with torch.no_grad():
            outputs = model(**inputs).logits
            preds = outputs.argmax(dim=-1)

        total_correct += (preds == labels).sum().item()
        total_samples += labels.size(0)

    accuracy = total_correct / total_samples
    return accuracy