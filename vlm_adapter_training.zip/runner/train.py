import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm

def freeze_model_except_adapters(model):
    for name, param in model.named_parameters():
        if "Sequential" in name or "adapter" in name:
            param.requires_grad = True
        else:
            param.requires_grad = False

def train_model(model, dataset, preprocess_fn=None, batch_size=8, epochs=3, device="cuda", lr=1e-4):
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=lr)
    criterion = nn.CrossEntropyLoss()

    model.train()
    model.to(device)

    for epoch in range(epochs):
        total_loss = 0.0
        for batch in tqdm(loader, desc=f"Training Epoch {epoch+1}"):
            inputs = preprocess_fn(batch) if preprocess_fn else batch
            labels = batch["labels"].to(device)

            outputs = model(**inputs).logits
            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        print(f"[Epoch {epoch+1}] Avg Loss: {total_loss / len(loader):.4f}")