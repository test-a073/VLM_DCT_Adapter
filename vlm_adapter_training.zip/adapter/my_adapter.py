import torch
import torch.nn as nn

class MyCustomAdapter(nn.Module):
    def __init__(self, hidden_dim=768, adapter_dim=16):
        super().__init__()
        self.down = nn.Linear(hidden_dim, adapter_dim)
        self.up = nn.Linear(adapter_dim, hidden_dim)
        self.act = nn.ReLU()

    def forward(self, x):
        return x + self.up(self.act(self.down(x)))