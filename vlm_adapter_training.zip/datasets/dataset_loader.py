from datasets import load_dataset

def load_dataset_vlm(dataset_name):
    if dataset_name == "vqa_v2":
        dataset = load_dataset("visual_genome", "vqa")
        dataset = dataset["train"].map(lambda e: {"inputs": e["question"], "labels": e["answer"]})
    elif dataset_name == "ok_vqa":
        dataset = load_dataset("ok_vqa")
        dataset = dataset["train"].map(lambda e: {"inputs": e["question"], "labels": e["answer"]})
    elif dataset_name == "coco_captions":
        dataset = load_dataset("coco_captions")
        dataset = dataset["train"].map(lambda e: {"inputs": e["image_id"], "labels": e["caption"]})
    else:
        raise ValueError(f"Unknown dataset {dataset_name}")
    return dataset