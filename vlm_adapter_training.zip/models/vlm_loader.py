from transformers import Blip2ForConditionalGeneration

def load_vlm(model_name):
    if model_name == "blip2":
        return Blip2ForConditionalGeneration.from_pretrained("Salesforce/blip2-opt-2.7b")
    else:
        raise ValueError(f"Unknown model {model_name}")